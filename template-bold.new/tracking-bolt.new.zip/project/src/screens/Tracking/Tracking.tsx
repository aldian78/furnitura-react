import React from "react";
import { OrderSummarySection } from "./sections/OrderSummarySection";
import { FooterSection } from "./sections/FooterSection";
import { NavigationBarSection } from "./sections/NavigationBarSection";
import { ShoppingCartSection } from "./sections/ShoppingCartSection";

export const Tracking = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full min-h-screen bg-bg-1">
      <NavigationBarSection />
      <ShoppingCartSection />
      <OrderSummarySection />
      <FooterSection />
    </div>
  );
};