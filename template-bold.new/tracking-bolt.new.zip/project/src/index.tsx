import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Tracking } from "./screens/Tracking/Tracking";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <Tracking />
  </StrictMode>,
);
