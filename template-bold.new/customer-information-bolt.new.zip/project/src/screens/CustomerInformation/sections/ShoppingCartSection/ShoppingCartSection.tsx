import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const ShoppingCartSection = (): JSX.Element => {
  // Define the steps data for the checkout process
  const checkoutSteps = [
    {
      id: 1,
      title: "CART",
      description: "Review all your product and edit the number.",
      icon: "/add-shopping-bag.svg",
      iconAlt: "Add shopping bag",
      isActive: true,
      isCompleted: true,
    },
    {
      id: 2,
      title: "CUSTOMER INFORMATION",
      description: "Add your name, phone number and address.",
      icon: "/user-circle.svg",
      iconAlt: "User circle",
      isActive: true,
      isCompleted: true,
    },
    {
      id: 3,
      title: "SHIPPING & PAYMENT",
      description: "With many payment method, included yours.",
      icon: "/credit-card.svg",
      iconAlt: "Credit card",
      isActive: false,
      isCompleted: false,
    },
    {
      id: 4,
      title: "REVIEW",
      description: "View all your information before the confimation.",
      icon: "/eye.svg",
      iconAlt: "Eye",
      isActive: false,
      isCompleted: false,
    },
  ];

  // Calculate the progress percentage for the progress bar
  const progressPercentage =
    (checkoutSteps.filter((step) => step.isCompleted).length /
      checkoutSteps.length) *
    100;

  return (
    <section className="w-full py-20">
      <div className="flex flex-col items-center gap-9 mx-auto max-w-7xl">
        <div className="text-center">
          <h1 className="font-h1-32-extra-bold text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
            SHIPPING &amp; PAYMENT
          </h1>
          <h2 className="mt-9 font-h3-16-bold text-black-3 text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)]">
            CHOOSE THE PAYMENT AND SHIPPING METHOD YOU WANT
          </h2>
        </div>

        {/* Progress bar */}
        <div className="relative w-full max-w-[898px] h-2 my-10">
          <div className="absolute w-full h-0.5 top-[3px] bg-black-5" />
          <div
            className="absolute h-0.5 top-[3px] bg-black-1"
            style={{ width: `${progressPercentage}%` }}
          />
          {checkoutSteps
            .filter((step) => step.isCompleted)
            .map((step, index) => (
              <div
                key={step.id}
                className="absolute w-2 h-2 top-0 bg-black-1 rounded"
                style={{
                  left: `${(index / (checkoutSteps.length - 1)) * 100}%`,
                }}
              />
            ))}
        </div>

        {/* Checkout steps */}
        <div className="flex w-full justify-between gap-4">
          {checkoutSteps.map((step) => (
            <Card
              key={step.id}
              className="flex-1 border-none shadow-none bg-transparent"
            >
              <CardContent className="flex flex-col items-center gap-3 p-0">
                <div
                  className={`flex w-14 h-14 items-center justify-center p-2.5 rounded-full ${step.isActive ? "bg-black-1" : "bg-black-7"}`}
                >
                  <img className="w-6 h-6" alt={step.iconAlt} src={step.icon} />
                </div>
                <h3 className="font-h3-16-bold text-black-1 text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)] text-center">
                  {step.title}
                </h3>
                <p className="w-[170px] font-h4-14-medium text-black-3 text-[length:var(--h4-14-medium-font-size)] text-center tracking-[var(--h4-14-medium-letter-spacing)] leading-[var(--h4-14-medium-line-height)] [font-style:var(--h4-14-medium-font-style)]">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
