import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Separator } from "../../../../components/ui/separator";

export const CartSection = (): JSX.Element => {
  // Product data
  const products = [
    {
      id: 1,
      name: "MORDERN BLACK STANDING METAL LIGHT",
      quantity: 1,
      price: "$235.41",
      image: "/img-1.svg",
    },
    {
      id: 2,
      name: "MORDERN BLACK STANDING METAL LIGHT",
      quantity: 3,
      price: "$35.73",
      image: "/img-2.svg",
    },
    {
      id: 3,
      name: "MORDERN BLACK STANDING METAL LIGHT",
      quantity: 1,
      price: "$352.41",
      image: "/img.svg",
    },
  ];

  // Order summary data
  const orderSummary = [
    { label: "Subtotal", value: "$1,725.00", highlight: false },
    { label: "Shipping", value: "-", highlight: false },
    { label: "Price", value: "$1,725.00", highlight: false },
    { label: "Discount 10%", value: "-$125.00", highlight: false },
    { label: "Total Price", value: "$1,600.00", highlight: true },
  ];

  return (
    <section className="flex w-full items-start gap-20 px-6 py-20 md:px-16 lg:px-[264px]">
      {/* Customer Information Section */}
      <div className="flex flex-col items-start gap-[72px] relative flex-1">
        <div className="flex flex-col items-start gap-9 w-full">
          <h1 className="w-full font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
            YOUR INFORMATION
          </h1>

          <p className="w-full font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
            Add your name, phone number and address.
          </p>
        </div>

        <div className="flex flex-col items-start gap-10 w-full">
          <div className="flex items-start gap-10 w-full">
            <div className="flex-1">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="Your first name"
              />
            </div>
            <div className="flex-1">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="Your last name"
              />
            </div>
          </div>

          <div className="flex items-start gap-10 w-full">
            <div className="flex-1">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="Your email"
              />
            </div>
            <div className="flex-1">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="Phone number"
              />
            </div>
          </div>

          <div className="flex items-start gap-10 w-full">
            <div className="w-96">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="County"
              />
            </div>
            <div className="flex-1">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="City"
              />
            </div>
            <div className="flex-1">
              <Input
                className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
                placeholder="ZIP Code"
              />
            </div>
          </div>

          <div className="w-full">
            <Input
              className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3"
              placeholder="Address details"
            />
          </div>
        </div>
      </div>

      {/* Separator */}
      <Separator orientation="vertical" className="h-auto" />

      {/* Order Summary Section */}
      <div className="flex flex-col w-[424px] items-start gap-[72px]">
        <div className="flex flex-col items-start gap-9 w-full">
          <h1 className="w-full font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
            YOUR ORDER
          </h1>

          <p className="w-full font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
            Review all the products you want to buy
          </p>
        </div>

        <div className="flex flex-col items-start gap-6 w-full">
          {products.map((product) => (
            <Card
              key={product.id}
              className="flex items-start gap-6 w-full border-none shadow-none p-0"
            >
              <CardContent className="flex items-start gap-6 p-0 w-full">
                <img
                  className="w-[104px] h-[136px] object-cover"
                  alt={product.name}
                  src={product.image}
                />
                <div className="flex flex-col items-start gap-4 flex-1">
                  <h3 className="w-full font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-black-1 text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)]">
                    {product.name}
                  </h3>
                  <p className="w-full font-h4-14-medium font-[number:var(--h4-14-medium-font-weight)] text-black-3 text-[length:var(--h4-14-medium-font-size)] tracking-[var(--h4-14-medium-letter-spacing)] leading-[var(--h4-14-medium-line-height)] [font-style:var(--h4-14-medium-font-style)]">
                    {product.quantity}{" "}
                    {product.quantity === 1 ? "item" : "items"}
                  </p>
                  <p className="w-full font-h2-20-extra-bold font-[number:var(--h2-20-extra-bold-font-weight)] text-black-1 text-[length:var(--h2-20-extra-bold-font-size)] tracking-[var(--h2-20-extra-bold-letter-spacing)] leading-[var(--h2-20-extra-bold-line-height)] [font-style:var(--h2-20-extra-bold-font-style)]">
                    {product.price}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Separator className="w-full" />

        <div className="flex flex-col items-start gap-9 w-full">
          <div className="flex flex-col items-start gap-6 w-full">
            {orderSummary.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between w-full"
              >
                <span className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
                  {item.label}
                </span>
                <span
                  className={`font-h2-20-extra-bold font-[number:var(--h2-20-extra-bold-font-weight)] ${item.highlight ? "text-[#ce0000]" : "text-black-1"} text-[length:var(--h2-20-extra-bold-font-size)] text-right tracking-[var(--h2-20-extra-bold-letter-spacing)] leading-[var(--h2-20-extra-bold-line-height)] [font-style:var(--h2-20-extra-bold-font-style)]`}
                >
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        <Button className="w-full bg-black-1 text-bg-1 rounded-none h-auto py-3">
          <span className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-bg-1 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
            CONTINUE TO SHIPPING
          </span>
        </Button>
      </div>
    </section>
  );
};
