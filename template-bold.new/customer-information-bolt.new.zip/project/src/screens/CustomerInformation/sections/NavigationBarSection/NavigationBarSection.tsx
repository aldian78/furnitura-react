import { HeartIcon, SearchIcon, ShoppingBagIcon } from "lucide-react";
import React from "react";
import { Input } from "../../../../components/ui/input";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "../../../../components/ui/navigation-menu";

// Navigation menu items data
const mainNavItems = [
  { label: "HOME", hasDropdown: false },
  { label: "SHOP", hasDropdown: true },
  { label: "BLOG", hasDropdown: false },
  { label: "ABOUT US", hasDropdown: false },
];

const rightNavItems = [
  { label: "LOVE", icon: HeartIcon },
  { label: "CART", icon: ShoppingBagIcon },
];

export const NavigationBarSection = (): JSX.Element => {
  return (
    <header className="flex items-center gap-20 px-[264px] py-[60px] bg-black-8 w-full">
      {/* Logo */}
      <img className="w-[200px] h-[42px]" alt="Logo" src="/logo.svg" />

      {/* SearchIcon Bar */}
      <div className="flex items-center gap-3 px-0 py-3 border-b border-neutral-300 w-[264px]">
        <SearchIcon className="w-5 h-5 text-black-3" />
        <Input
          className="border-none p-0 h-auto font-h3-16-medium text-black-3 placeholder:text-black-3 focus-visible:ring-0"
          type="text"
          placeholder="SearchIcon something"
        />
      </div>

      {/* Main Navigation */}
      <NavigationMenu className="flex-1">
        <NavigationMenuList className="flex items-center gap-11">
          {mainNavItems.map((item, index) => (
            <NavigationMenuItem key={index}>
              {item.hasDropdown ? (
                <>
                  <NavigationMenuTrigger className="flex items-center gap-0.5 bg-transparent p-0 h-auto font-h3-16-bold text-black-1">
                    {item.label}
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    {/* Dropdown content would go here */}
                  </NavigationMenuContent>
                </>
              ) : (
                <span className="flex items-center gap-0.5 font-h3-16-bold text-black-1">
                  {item.label}
                </span>
              )}
            </NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>

      {/* Right Navigation */}
      <div className="flex items-center justify-end gap-11 flex-1">
        {rightNavItems.map((item, index) => {
          const IconComponent = item.icon;
          return (
            <div key={index} className="inline-flex items-center gap-1">
              <IconComponent className="w-5 h-5" />
              <span className="font-h3-16-bold text-black-1">{item.label}</span>
            </div>
          );
        })}
      </div>
    </header>
  );
};
