import React from "react";
import { BestSellersSection } from "./sections/BestSellersSection";
import { CallToActionSection } from "./sections/CallToActionSection";
import { CustomerReviewsSection } from "./sections/CustomerReviewsSection";
import { DeliveryInformationSection } from "./sections/DeliveryInformationSection";
import { FooterSection } from "./sections/FooterSection";
import { FrequentlyAskedQuestionsSection } from "./sections/FrequentlyAskedQuestionsSection";
import { ProductDetailsSection } from "./sections/ProductDetailsSection";
import { WhyChooseUsSection } from "./sections/WhyChooseUsSection";

export const ProductDetailScreen = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full bg-bg-1">
      <ProductDetailsSection />
      <DeliveryInformationSection />
      <CallToActionSection />
      <WhyChooseUsSection />
      <CustomerReviewsSection />
      <FrequentlyAskedQuestionsSection />
      <BestSellersSection />
      <FooterSection />
    </div>
  );
};
