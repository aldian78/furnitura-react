import {
  HeartIcon,
  MinusIcon,
  PlusIcon,
  SearchIcon,
  StarIcon,
} from "lucide-react";
import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "../../../../components/ui/navigation-menu";
import { Separator } from "../../../../components/ui/separator";
import {
  ToggleGroup,
  ToggleGroupItem,
} from "../../../../components/ui/toggle-group";

export const ProductDetailsSection = (): JSX.Element => {
  // Navigation menu items
  const navItems = [
    { label: "HOME", hasDropdown: false },
    { label: "SHOP", hasDropdown: true },
    { label: "BLOG", hasDropdown: false },
    { label: "ABOUT US", hasDropdown: false },
  ];

  // Product types
  const productTypes = ["Long", "Medium", "Short"];

  // Product colors
  const productColors = ["Coban", "Saphire", "Emerald", "Ruby"];

  return (
    <section className="w-full bg-black-7 mb-20">
      <header className="flex items-center gap-20 px-[264px] py-[60px]">
        <img className="w-[200px] h-[42px]" alt="Logo" src="/logo.svg" />

        <div className="flex items-center gap-3 py-3 border-b border-neutral-300 w-[264px]">
          <SearchIcon className="w-5 h-5" />
          <span className="font-h3-16-medium text-black-3">Furniture</span>
        </div>

        <NavigationMenu className="flex-1">
          <NavigationMenuList className="flex items-center gap-11">
            {navItems.map((item, index) => (
              <NavigationMenuItem key={index}>
                {item.hasDropdown ? (
                  <NavigationMenuTrigger className="font-h3-16-bold text-black-1 flex items-center gap-0.5 bg-transparent p-0 h-auto">
                    {item.label}
                  </NavigationMenuTrigger>
                ) : (
                  <Button
                    variant="ghost"
                    className="font-h3-16-bold text-black-1 p-0 h-auto"
                  >
                    {item.label}
                  </Button>
                )}
                {item.hasDropdown && (
                  <NavigationMenuContent>
                    {/* Dropdown content would go here */}
                  </NavigationMenuContent>
                )}
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu>

        <div className="flex items-center justify-end gap-11 flex-1">
          <Button
            variant="ghost"
            className="flex items-center gap-1 p-0 h-auto"
          >
            <HeartIcon className="w-5 h-5" />
            <span className="font-h3-16-bold text-black-1">LOVE</span>
          </Button>
          <Button
            variant="ghost"
            className="flex items-center gap-1 p-0 h-auto"
          >
            <img
              className="w-5 h-5"
              alt="Add shopping bag"
              src="/add-shopping-bag.svg"
            />
            <span className="font-h3-16-bold text-black-1">CART</span>
          </Button>
        </div>
      </header>

      <div className="px-[264px] pb-20">
        <div className="font-normal text-base leading-4 [font-family:'Lato',Helvetica] mb-12">
          <span className="leading-5 font-medium text-[#7e7f7c]">
            Home/Furniture/
          </span>
          <span className="font-h3-16-bold text-black-1">
            Modern bronze hanging light
          </span>
        </div>

        <div className="flex gap-12 items-start">
          {/* Product Image Section */}
          <div className="relative w-[600px] h-[500px] flex items-center justify-center">
            <div className="w-[350px] h-[350px] rounded-full [background:linear-gradient(180deg,rgba(217,218,225,1)_0%,rgba(148,151,152,1)_100%)]" />
            <img
              className="w-[580px] h-[240px] absolute bottom-8 left-1/2 transform -translate-x-1/2 object-contain"
              alt="Product"
              src="/img.png"
            />
          </div>

          {/* Product Details Section */}
          <Card className="flex-1 max-w-[520px] shadow-[0px_0px_0px_#0000000d,0px_20px_45px_#0000000a,0px_81px_81px_#0000000a,0px_183px_110px_#00000005,0px_326px_130px_#00000003,0px_509px_142px_transparent] bg-black-8">
            <CardContent className="flex flex-col gap-8 p-12">
              <h1 className="font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
                RADIANCE MODERN SOFA
              </h1>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className="w-5 h-5 fill-current text-yellow-400"
                    />
                  ))}
                </div>
                <Badge className="bg-[#ce0000] text-bg-1 font-h4-14-medium px-3 py-1 rounded-none">
                  ON SALE
                </Badge>
              </div>

              <div className="flex items-center gap-3">
                <span className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
                  261 products sold
                </span>
                <div className="w-1 h-1 bg-black-3 rounded-sm" />
                <span className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
                  3,1k products watched
                </span>
              </div>

              <Separator className="w-[280px]" />

              <div className="flex flex-col gap-6">
                <span className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
                  Type:
                </span>
                <ToggleGroup
                  type="single"
                  defaultValue="Long"
                  className="flex gap-4"
                >
                  {productTypes.map((type) => (
                    <ToggleGroupItem
                      key={type}
                      value={type}
                      className={`w-[124px] h-10 font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)] ${type === "Long" ? "bg-black-1 text-black-7" : "bg-black-7 text-black-1"}`}
                    >
                      {type}
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>

              <div className="flex flex-col gap-6">
                <span className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
                  Color
                </span>
                <ToggleGroup
                  type="single"
                  defaultValue="Emerald"
                  className="flex gap-4"
                >
                  {productColors.map((color) => (
                    <ToggleGroupItem
                      key={color}
                      value={color}
                      className={`w-[124px] h-10 font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)] ${color === "Emerald" ? "bg-[#3f625e] text-black-7" : "bg-black-7 text-black-1"}`}
                    >
                      {color}
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>

              <Separator className="w-[280px]" />

              <div className="flex items-center justify-between w-full">
                <div className="flex h-12 items-center gap-3 px-6 py-3 bg-black-7 rounded-sm">
                  <MinusIcon className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity" />
                  <div className="flex items-center gap-2 font-['Lato',Helvetica] font-normal text-base">
                    <span className="font-medium text-black-3">Number:</span>
                    <span className="font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-black-1 text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)]">
                      1
                    </span>
                  </div>
                  <PlusIcon className="w-5 h-5 cursor-pointer hover:opacity-70 transition-opacity" />
                </div>
                
                <div className="font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-[#ce0000] text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
                  $2352.41
                </div>
              </div>

              <div className="flex gap-4 mt-4">
                <Button className="flex-1 bg-black-1 text-bg-1 font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)] h-12 rounded-none hover:bg-black-1/90">
                  ADD TO CART
                </Button>
                <Button variant="outline" className="h-12 w-12 p-0 rounded-none border-black-1 hover:bg-black-1 hover:text-bg-1">
                  <HeartIcon className="w-5 h-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};