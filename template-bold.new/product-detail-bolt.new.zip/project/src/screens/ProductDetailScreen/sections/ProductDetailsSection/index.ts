export { ProductDetailsSection } from "./ProductDetailsSection";
