export { FrequentlyAskedQuestionsSection } from "./FrequentlyAskedQuestionsSection";
