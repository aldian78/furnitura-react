import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";

export const CallToActionSection = (): JSX.Element => {
  // Images data for the section
  const images = [
    {
      src: "/img-1.png",
      alt: "Decorative item",
      className: "w-[122px] h-[202px]",
    },
    {
      src: "/img-2.png",
      alt: "Furniture piece",
      className: "w-[182px] h-[253px]",
    },
    {
      src: "/img-3.png",
      alt: "Room setting",
      className: "w-[685px] h-[282px]",
    },
  ];

  return (
    <section className="w-full py-20">
      <Card className="mx-auto max-w-7xl bg-black-7 border-none">
        <CardContent className="p-0 relative flex flex-col md:flex-row items-center">
          {/* Left side with images */}
          <div className="relative w-full md:w-1/2 h-[363px]">
            {images.map((image, index) => (
              <img
                key={index}
                className={`absolute ${image.className} ${
                  index === 0
                    ? "top-[83px] left-[448px]"
                    : index === 1
                      ? "top-0 left-[52px]"
                      : "top-36 left-0"
                }`}
                alt={image.alt}
                src={image.src}
              />
            ))}
          </div>

          {/* Right side with form */}
          <div className="w-full md:w-1/2 px-8 py-12 flex flex-col space-y-6">
            <h2 className="font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
              GET IN TOUCH
            </h2>

            <p className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)] max-w-[508px]">
              We'd love to hear from you: connect with us for a seamless
              shopping experience and personalized assistance.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <div className="flex-grow">
                <Input
                  className="border-t-0 border-l-0 border-r-0 rounded-none px-0 py-3 font-h3-16-medium text-black-3 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0"
                  placeholder="Your E-mail"
                />
              </div>

              <Button className="w-60 bg-black-1 text-bg-1 font-h3-16-medium hover:bg-black-1/90">
                Subcribes
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
