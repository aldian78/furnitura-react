import { StarIcon } from "lucide-react";
import React from "react";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "../../../../components/ui/avatar";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../../../components/ui/select";
import { Separator } from "../../../../components/ui/separator";
import { Textarea } from "../../../../components/ui/textarea";

// Review data for mapping
const reviews = [
  {
    id: 1,
    name: "Val Purvis",
    date: "July, 23 2020",
    rating: 5,
    title: "Great Product",
    content:
      "I love my new Nova Lounge Sofa! The clean lines and premium upholstery make it a sleek addition to my living room, and the adjustable headrests add an extra touch of comfort. Highly recommend!",
    avatar: "/image.png",
    expanded: true,
  },
  {
    id: 2,
    name: "Phoebe Kunis",
    date: "July, 23 2020",
    rating: 5,
    title: "Great Product",
    content:
      "Perfect centerpiece for my home. Its chic design and comfortable cushions make it ideal for lounging, and the high-quality materials mean it will last for years to come.",
    avatar: "/image-1.png",
    expanded: true,
  },
  {
    id: 3,
    name: "Dianne Russell",
    date: "July, 23 2020",
    rating: 5,
    title: "Great Product",
    content:
      "The Zenith Modern Chair is a game-changer for my workspace. Its minimalist design fits perfectly with my aesthetic, and the durable materials make it a worthwhile investment...",
    avatar: "/image-2.png",
    expanded: false,
  },
  {
    id: 4,
    name: "Kendall Mckernan",
    date: "July, 23 2020",
    rating: 5,
    title: "Great Product",
    content:
      "I can't get enough of my new Luminous Lounge Sofa! The reclining seats and headrests make it perfect for movie nights, and the sleek design adds a touch of sophistication to...",
    avatar: "/image-3.png",
    expanded: false,
  },
];

export const CustomerReviewsSection = (): JSX.Element => {
  return (
    <section className="flex flex-col md:flex-row gap-8 md:gap-20 px-4 md:px-16 lg:px-64 py-16 md:py-20">
      {/* Review Form */}
      <div className="flex flex-col gap-16 md:gap-18 w-full md:w-auto md:min-w-[368px]">
        <div className="flex flex-col gap-9">
          <div className="space-y-2">
            <h2 className="font-h1-32-extra-bold text-black-1 tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)]">
              YOUR REVIEW
            </h2>
            <p className="font-h3-16-medium text-black-3 tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)]">
              About mordern hanging bronze light
            </p>
          </div>

          <div className="flex flex-col gap-9">
            <div className="border-b border-neutral-300">
              <Input
                className="px-0 py-3 font-h3-16-medium text-black-3 border-none focus-visible:ring-0 focus-visible:ring-offset-0"
                placeholder="Your Name"
              />
            </div>

            <div className="border-b border-neutral-300">
              <Input
                className="px-0 py-3 font-h3-16-medium text-black-3 border-none focus-visible:ring-0 focus-visible:ring-offset-0"
                placeholder="Your E-mail"
              />
            </div>

            <div className="border-b border-neutral-300">
              <Select defaultValue="5">
                <SelectTrigger className="px-0 py-3 border-none focus:ring-0 focus:ring-offset-0">
                  <SelectValue
                    placeholder="Select rating"
                    className="font-h3-16-bold text-black-1"
                  />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5" className="font-h3-16-bold">
                    5 Stars
                  </SelectItem>
                  <SelectItem value="4" className="font-h3-16-bold">
                    4 Stars
                  </SelectItem>
                  <SelectItem value="3" className="font-h3-16-bold">
                    3 Stars
                  </SelectItem>
                  <SelectItem value="2" className="font-h3-16-bold">
                    2 Stars
                  </SelectItem>
                  <SelectItem value="1" className="font-h3-16-bold">
                    1 StarIcon
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="border-b border-neutral-300">
              <Textarea
                className="px-0 pt-3 pb-20 min-h-[100px] font-h3-16-medium text-black-3 border-none resize-none focus-visible:ring-0 focus-visible:ring-offset-0"
                placeholder="This product is..."
              />
            </div>
          </div>

          <Button className="w-full bg-black-1 text-bg-1 font-h3-16-medium rounded-none hover:bg-black-1/90">
            Submit
          </Button>
        </div>
      </div>

      {/* Separator */}
      <Separator orientation="vertical" className="hidden md:block h-auto" />

      {/* Reviews List */}
      <div className="flex flex-col gap-9 flex-1">
        {reviews.map((review) => (
          <Card key={review.id} className="border-none shadow-none">
            <CardContent className="p-0 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={review.avatar} alt={review.name} />
                    <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-1">
                    <h3 className="font-h3-16-bold text-black-1 tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)]">
                      {review.name}
                    </h3>
                    <p className="font-h4-14-medium text-black-3 tracking-[var(--h4-14-medium-letter-spacing)] leading-[var(--h4-14-medium-line-height)]">
                      {review.date}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {[...Array(review.rating)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className="w-5 h-5 fill-current text-yellow-400"
                    />
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <h4 className="font-h3-16-bold text-neutral-1 tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)]">
                  {review.title}
                </h4>
                <p
                  className={`font-medium text-black-3 text-base leading-7 ${!review.expanded ? "font-normal" : ""}`}
                >
                  {review.content}
                  {!review.expanded && (
                    <span className="font-h3-16-bold text-black-1 tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] ml-1 cursor-pointer">
                      Read more
                    </span>
                  )}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
