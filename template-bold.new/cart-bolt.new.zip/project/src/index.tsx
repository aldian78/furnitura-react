import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { CartScreen } from "./screens/CartScreen/CartScreen";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <CartScreen />
  </StrictMode>,
);
