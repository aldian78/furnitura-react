import {
  ChevronDownIcon,
  HeartIcon,
  SearchIcon,
  ShoppingBagIcon,
} from "lucide-react";
import React from "react";
import { Input } from "../../../../components/ui/input";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "../../../../components/ui/navigation-menu";

// Navigation menu items data
const navItems = [
  { label: "HOME", hasDropdown: false },
  { label: "SHOP", hasDropdown: true },
  { label: "BLOG", hasDropdown: false },
  { label: "ABOUT US", hasDropdown: false },
];

// Right side menu items data
const rightNavItems = [
  { label: "LOVE", icon: <HeartIcon className="w-5 h-5" /> },
  { label: "CART", icon: <ShoppingBagIcon className="w-5 h-5" /> },
];

export const NavigationBarSection = (): JSX.Element => {
  return (
    <header className="flex items-center gap-20 px-[264px] py-[60px] relative bg-black-8 w-full">
      {/* Logo */}
      <img className="relative w-[200px] h-[42px]" alt="Logo" src="/logo.svg" />

      {/* SearchIcon Bar */}
      <div className="flex items-center gap-3 px-0 py-3 relative border-b border-neutral-300 w-[264px]">
        <SearchIcon className="w-5 h-5 text-black-3" />
        <Input
          className="border-none p-0 h-auto font-h3-16-medium text-black-3 placeholder:text-black-3 focus-visible:ring-0 focus-visible:ring-offset-0"
          type="text"
          placeholder="SearchIcon something"
        />
      </div>

      {/* Main Navigation */}
      <NavigationMenu className="flex-1">
        <NavigationMenuList className="flex items-center gap-11">
          {navItems.map((item, index) => (
            <NavigationMenuItem key={index}>
              {item.hasDropdown ? (
                <>
                  <NavigationMenuTrigger className="flex items-center gap-0.5 bg-transparent p-0 h-auto font-h3-16-bold text-black-1">
                    {item.label}
                    <ChevronDownIcon className="w-5 h-5" />
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    {/* Dropdown content would go here */}
                  </NavigationMenuContent>
                </>
              ) : (
                <span className="flex items-center gap-0.5 font-h3-16-bold text-black-1">
                  {item.label}
                </span>
              )}
            </NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>

      {/* Right Side Navigation */}
      <div className="flex items-center justify-end gap-11 flex-1">
        {rightNavItems.map((item, index) => (
          <div key={index} className="inline-flex items-center gap-1">
            {item.icon}
            <span className="font-h3-16-bold text-black-1">{item.label}</span>
          </div>
        ))}
      </div>
    </header>
  );
};
