import React from "react";
import { BestCombinedWithSection } from "./sections/BestCombinedWithSection";
import { CartSection } from "./sections/CartSection";
import { FooterSection } from "./sections/FooterSection/FooterSection";
import { NavigationBarSection } from "./sections/NavigationBarSection";
import { ShoppingCartSection } from "./sections/ShoppingCartSection";
import { WhyChooseUsSection } from "./sections/WhyChooseUsSection";

export const CartScreen = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full bg-bg-1">
      <NavigationBarSection />
      <ShoppingCartSection />
      <CartSection />
      <WhyChooseUsSection />
      <BestCombinedWithSection />
      <FooterSection />
    </div>
  );
};
