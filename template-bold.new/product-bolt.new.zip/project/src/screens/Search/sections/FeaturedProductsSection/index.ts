export { FeaturedProductsSection } from "./FeaturedProductsSection";
