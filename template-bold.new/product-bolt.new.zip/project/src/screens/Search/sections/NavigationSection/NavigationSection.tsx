import {
  ChevronDownIcon,
  HeartIcon,
  SearchIcon,
  ShoppingBagIcon,
} from "lucide-react";
import React from "react";
import { Input } from "../../../../components/ui/input";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../../../components/ui/navigation-menu";

// Navigation menu items data
const navItems = [
  { label: "HOME", hasDropdown: false },
  { label: "SHOP", hasDropdown: true },
  { label: "BLOG", hasDropdown: false },
  { label: "ABOUT US", hasDropdown: false },
];

// Right side menu items data
const rightNavItems = [
  { label: "LOVE", icon: <HeartIcon className="w-5 h-5" /> },
  { label: "CART", icon: <ShoppingBagIcon className="w-5 h-5" /> },
];

export const NavigationSection = (): JSX.Element => {
  return (
    <header className="flex w-full items-center gap-20 px-16 py-[60px] bg-black-8 border-b border-neutral-300">
      <img className="w-[200px] h-[42px]" alt="Logo" src="/logo.svg" />

      <div className="flex items-center gap-3 py-3 border-b border-neutral-300">
        <SearchIcon className="w-5 h-5" />
        <Input
          className="border-0 p-0 h-auto font-h3-16-medium text-black-3 focus-visible:ring-0 focus-visible:ring-offset-0 placeholder:text-black-3"
          placeholder="Furniture"
          defaultValue="Furniture"
        />
      </div>

      <NavigationMenu className="flex-1">
        <NavigationMenuList className="flex items-center gap-11">
          {navItems.map((item, index) => (
            <NavigationMenuItem
              key={index}
              className="flex items-start gap-0.5"
            >
              <NavigationMenuLink className="font-h3-16-bold text-black-1 whitespace-nowrap">
                {item.label}
                {item.hasDropdown && (
                  <ChevronDownIcon className="inline-block w-5 h-5 ml-0.5" />
                )}
              </NavigationMenuLink>
            </NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>

      <div className="flex items-center justify-end gap-11 flex-1">
        {rightNavItems.map((item, index) => (
          <div key={index} className="inline-flex items-start gap-1">
            {item.icon}
            <div className="font-h3-16-bold text-black-1 whitespace-nowrap">
              {item.label}
            </div>
          </div>
        ))}
      </div>
    </header>
  );
};
