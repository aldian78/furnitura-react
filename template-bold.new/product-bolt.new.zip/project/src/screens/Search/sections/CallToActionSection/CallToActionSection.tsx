import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Card, CardContent } from "../../../../components/ui/card";

export const CallToActionSection = (): JSX.Element => {
  // Data for stars to map over
  const stars = Array(5).fill(null);

  return (
    <section className="w-full py-8">
      <Card className="relative w-full h-[341px] bg-black-7 overflow-hidden">
        <CardContent className="p-0 h-full">
          <div className="relative h-full">
            {/* Product information */}
            <div className="absolute top-[63px] left-16">
              <h2 className="font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
                MODERN BRONZE
                <br />
                HANGING LIGHT
              </h2>
            </div>

            {/* Star rating */}
            <div className="flex items-center gap-1 absolute top-40 left-16">
              {stars.map((_, index) => (
                <img
                  key={index}
                  className="w-4 h-4"
                  alt="Star"
                  src="/star.svg"
                />
              ))}
            </div>

            {/* Current price */}
            <div className="absolute top-60 left-[66px] font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] whitespace-nowrap [font-style:var(--h1-32-extra-bold-font-style)]">
              $2352.41
            </div>

            {/* Original price (crossed out) */}
            <div className="absolute top-[211px] left-[66px] font-bold text-black-3 text-base leading-5 line-through whitespace-nowrap [font-family:'Lato',Helvetica] tracking-[0]">
              $3252.41
            </div>

            {/* Discount badge */}
            <Badge className="absolute top-[247px] left-[220px] bg-[#ce0000] text-black-8 px-2 py-1 rounded">
              <span className="font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-[length:var(--h3-16-bold-font-size)] leading-[var(--h3-16-bold-line-height)] tracking-[var(--h3-16-bold-letter-spacing)] [font-style:var(--h3-16-bold-font-style)]">
                -30%
              </span>
            </Badge>

            {/* Product image */}
            <img
              className="absolute w-[308px] h-[442px] top-0 right-0"
              alt="Modern Bronze Hanging Light"
              src="/img.png"
            />
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
