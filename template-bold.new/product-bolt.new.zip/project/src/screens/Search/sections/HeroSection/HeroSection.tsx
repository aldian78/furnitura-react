import React from "react";

export const HeroSection = (): JSX.Element => {
  return (
    <section className="w-full py-16 bg-[url(/rectangle-1.svg)] bg-cover bg-center">
      <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center">
        <div className="md:w-1/2">
          {/* This div is for the image that's shown in the background */}
        </div>

        <div className="md:w-1/2 space-y-4">
          <h3 className="font-['Lato',Helvetica] font-bold text-black-1 text-xl leading-7">
            WELCOME TO OUR
          </h3>

          <h1 className="font-['Montserrat',Helvetica] text-8xl tracking-tight leading-[100px]">
            <span className="font-extrabold text-[#2f302c] block">
              FURNITURE
            </span>
            <span className="font-bold text-[#2f302c]">GALLERY</span>
          </h1>

          <div className="w-[308px] h-px bg-[url(/line-1.svg)] my-6"></div>

          <h3 className="font-['Lato',Helvetica] font-bold text-black-1 text-xl leading-7">
            BROWSE OUR SELECTIONS
          </h3>

          <p className="max-w-[374px] font-h3-16-medium text-black-3 leading-[var(--h3-16-medium-line-height)]">
            Featuring sleek designs and innovative materials that seamlessly
            blend form and function.
          </p>
        </div>
      </div>
    </section>
  );
};