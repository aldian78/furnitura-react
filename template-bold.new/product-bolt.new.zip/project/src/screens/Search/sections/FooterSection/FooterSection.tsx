import {
  FacebookIcon,
  InstagramIcon,
  TwitterIcon,
  YoutubeIcon,
} from "lucide-react";
import React from "react";
import { Separator } from "../../../../components/ui/separator";

export const FooterSection = (): JSX.Element => {
  // Footer column data
  const footerColumns = [
    {
      title: "CUSTOMER SERVICE",
      links: [
        "Help & FAQs",
        "Return & Refund",
        "Shipping Policy",
        "Customs and Taxes",
        "Customers's Reviews",
      ],
    },
    {
      title: "COMPANY",
      links: [
        "About Japan with love",
        "Contact Us",
        "Special Deals & Offers",
        "Terms of Service",
        "Privacy Policy",
      ],
    },
    {
      title: "HELP CENTER",
      links: [
        "Order Information",
        "Shipping Options",
        "International Shipping",
        "Payment Options",
      ],
    },
    {
      title: "RETURN & WARRANTLY",
      links: [
        "Returns & Exchange Policy",
        "Returns Center",
        "Warranty Policy",
        "Warranty Registration",
        "Warranty Repair Center",
      ],
    },
  ];

  // Social media icons
  const socialIcons = [
    { icon: <FacebookIcon size={17} />, name: "Facebook" },
    { icon: <TwitterIcon size={17} />, name: "Twitter" },
    { icon: <InstagramIcon size={17} />, name: "Instagram" },
    { icon: <YoutubeIcon size={17} />, name: "Youtube" },
  ];

  return (
    <footer className="flex flex-col w-full items-center gap-[72px] pt-28 pb-[72px] px-6 md:px-16 lg:px-[264px] bg-bg-1">
      <div className="gap-8 md:gap-[120px] w-full flex flex-wrap md:flex-nowrap items-start">
        {footerColumns.map((column, index) => (
          <div key={index} className="flex-col gap-7 flex-1 flex items-start">
            <h2 className="self-stretch mt-[-1.00px] font-h2-20-extra-bold font-[number:var(--h2-20-extra-bold-font-weight)] text-black-1 text-[length:var(--h2-20-extra-bold-font-size)] leading-[var(--h2-20-extra-bold-line-height)] tracking-[var(--h2-20-extra-bold-letter-spacing)] [font-style:var(--h2-20-extra-bold-font-style)]">
              {column.title}
            </h2>

            {column.links.map((link, linkIndex) => (
              <a
                key={linkIndex}
                href="#"
                className="self-stretch font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)] hover:text-black-1 transition-colors"
              >
                {link}
              </a>
            ))}
          </div>
        ))}
      </div>

      <Separator className="w-full h-px" />

      <div className="flex flex-col md:flex-row items-center md:items-start justify-between w-full gap-6 md:gap-[72px]">
        <p className="font-h3-16-medium font-[number:var(--h3-16-medium-font-weight)] text-black-3 text-[length:var(--h3-16-medium-font-size)] tracking-[var(--h3-16-medium-letter-spacing)] leading-[var(--h3-16-medium-line-height)] [font-style:var(--h3-16-medium-font-style)]">
          Furnitur © Copyright 2020, Inc. All rights reserved
        </p>

        <div className="flex items-center gap-8">
          {socialIcons.map((social, index) => (
            <a
              key={index}
              href="#"
              className="w-5 h-5 flex items-center justify-center hover:text-black-1 text-black-3 transition-colors"
              aria-label={social.name}
            >
              {social.icon}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
};
