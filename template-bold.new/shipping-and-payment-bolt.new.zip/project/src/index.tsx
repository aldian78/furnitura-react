import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { ShippingAndPayment } from "./screens/ShippingAndPayment/ShippingAndPayment";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <ShippingAndPayment />
  </StrictMode>,
);
