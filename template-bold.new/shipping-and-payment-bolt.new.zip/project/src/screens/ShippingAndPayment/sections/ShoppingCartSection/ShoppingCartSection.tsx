import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const ShoppingCartSection = (): JSX.Element => {
  // Data for checkout steps
  const checkoutSteps = [
    {
      id: 1,
      title: "CART",
      description: "Review all your product and edit the number.",
      icon: "/add-shopping-bag.svg",
      iconAlt: "Add shopping bag",
      isActive: true,
      isCompleted: true,
    },
    {
      id: 2,
      title: "CUSTOMER INFORMATION",
      description: "Add your name, phone number and address.",
      icon: "/user-circle.svg",
      iconAlt: "User circle",
      isActive: true,
      isCompleted: true,
    },
    {
      id: 3,
      title: "SHIPPING & PAYMENT",
      description: "With many payment method, included yours.",
      icon: "/credit-card.svg",
      iconAlt: "Credit card",
      isActive: true,
      isCompleted: false,
    },
    {
      id: 4,
      title: "REVIEW",
      description: "View all your information before the confimation.",
      icon: "/eye.svg",
      iconAlt: "Eye",
      isActive: false,
      isCompleted: false,
    },
  ];

  return (
    <section className="flex flex-col items-center w-full py-20">
      <div className="flex flex-col w-full max-w-7xl items-center gap-9 mb-16">
        <h1 className="font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] text-center tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] whitespace-nowrap">
          CUSTOMER INFORMATION
        </h1>

        <h2 className="font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-black-3 text-[length:var(--h3-16-bold-font-size)] text-center leading-[var(--h3-16-bold-line-height)] whitespace-nowrap tracking-[var(--h3-16-bold-letter-spacing)] [font-style:var(--h3-16-bold-font-style)]">
          PROVIDE YOUR RECIEVED INFORMATIONS TO COMPLETE THE PROCESS
        </h2>
      </div>

      {/* Progress bar */}
      <div className="relative w-full max-w-3xl h-2 mb-9">
        <div className="absolute w-full h-0.5 top-[3px] left-1 bg-black-5" />
        <div className="absolute w-[83%] h-0.5 top-[3px] left-1 bg-black-1" />
        <div className="absolute w-2 h-2 top-0 left-0 bg-black-1 rounded" />
        <div className="absolute w-2 h-2 top-0 left-[33%] bg-black-1 rounded" />
        <div className="absolute w-2 h-2 top-0 left-[66%] bg-black-1 rounded" />
        <div className="absolute w-2 h-2 top-0 right-0 bg-black-5 rounded" />
      </div>

      {/* Checkout steps */}
      <div className="flex w-full max-w-5xl items-start justify-between">
        {checkoutSteps.map((step) => (
          <Card
            key={step.id}
            className="flex flex-col items-center gap-3 border-none bg-transparent shadow-none flex-1"
          >
            <CardContent className="flex flex-col items-center gap-3 p-0">
              <div
                className={`flex w-14 h-14 items-center justify-center gap-2.5 p-2.5 rounded-full ${step.isActive ? "bg-black-1" : "bg-black-7"}`}
              >
                <img className="w-6 h-6" alt={step.iconAlt} src={step.icon} />
              </div>

              <h3 className="font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-black-1 text-[length:var(--h3-16-bold-font-size)] leading-[var(--h3-16-bold-line-height)] whitespace-nowrap tracking-[var(--h3-16-bold-letter-spacing)] [font-style:var(--h3-16-bold-font-style)]">
                {step.title}
              </h3>

              <p className="w-[170px] font-h4-14-medium font-[number:var(--h4-14-medium-font-weight)] text-black-3 text-[length:var(--h4-14-medium-font-size)] text-center tracking-[var(--h4-14-medium-letter-spacing)] leading-[var(--h4-14-medium-line-height)] [font-style:var(--h4-14-medium-font-style)]">
                {step.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
