import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { ReviewYourOrder } from "./screens/ReviewYourOrder";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <ReviewYourOrder />
  </StrictMode>,
);
