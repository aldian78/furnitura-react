import {
  CreditCardIcon,
  EyeIcon,
  ShoppingBagIcon,
  UserIcon,
} from "lucide-react";
import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const ShoppingCartSection = (): JSX.Element => {
  // Data for checkout steps
  const checkoutSteps = [
    {
      icon: <ShoppingBagIcon className="h-6 w-6" />,
      title: "CART",
      description: "Review all your product and edit the number.",
    },
    {
      icon: <UserIcon className="h-6 w-6" />,
      title: "CUSTOMER INFORMATION",
      description: "Add your name, phone number and address.",
    },
    {
      icon: <CreditCardIcon className="h-6 w-6" />,
      title: "SHIPPING & PAYMENT",
      description: "With many payment method, included yours.",
    },
    {
      icon: <EyeIcon className="h-6 w-6" />,
      title: "REVIEW",
      description: "View all your information before the confimation.",
    },
  ];

  return (
    <section className="w-full py-20">
      <div className="flex flex-col items-center gap-9 mx-auto max-w-7xl">
        <div className="text-center">
          <h1 className="font-h1-32-extra-bold font-[number:var(--h1-32-extra-bold-font-weight)] text-black-1 text-[length:var(--h1-32-extra-bold-font-size)] tracking-[var(--h1-32-extra-bold-letter-spacing)] leading-[var(--h1-32-extra-bold-line-height)] [font-style:var(--h1-32-extra-bold-font-style)]">
            REVIEW AND CONFIRMATION
          </h1>
          <h2 className="mt-9 font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-black-3 text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)]">
            LOOKBACK ONE MORE TIME TO CONFIRM YOUR ADDRESS AND ALL YOUR PRODUCTS
          </h2>
        </div>

        {/* Progress bar */}
        <div className="relative w-full max-w-[902px] h-2 my-10">
          <div className="absolute w-full h-0.5 top-[3px] bg-black-5" />
          <div className="absolute w-full h-0.5 top-[3px] bg-black-1" />

          {/* Progress dots */}
          <div className="absolute w-full flex justify-between">
            {[0, 1, 2, 3].map((index) => (
              <div key={index} className="w-2 h-2 bg-black-1 rounded-full" />
            ))}
          </div>
        </div>

        {/* Checkout steps */}
        <div className="flex w-full justify-between gap-4">
          {checkoutSteps.map((step, index) => (
            <Card key={index} className="border-none shadow-none flex-1">
              <CardContent className="flex flex-col items-center gap-3 p-0">
                <div className="flex w-14 h-14 items-center justify-center bg-black-1 rounded-full">
                  {step.icon}
                </div>
                <h3 className="font-h3-16-bold font-[number:var(--h3-16-bold-font-weight)] text-black-1 text-[length:var(--h3-16-bold-font-size)] tracking-[var(--h3-16-bold-letter-spacing)] leading-[var(--h3-16-bold-line-height)] [font-style:var(--h3-16-bold-font-style)]">
                  {step.title}
                </h3>
                <p className="w-[170px] text-center font-h4-14-medium font-[number:var(--h4-14-medium-font-weight)] text-black-3 text-[length:var(--h4-14-medium-font-size)] tracking-[var(--h4-14-medium-letter-spacing)] leading-[var(--h4-14-medium-line-height)] [font-style:var(--h4-14-medium-font-style)]">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
