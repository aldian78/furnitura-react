export { CustomerReviewsSection } from "./CustomerReviewsSection";
