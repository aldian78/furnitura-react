import React from "react";
import { BenefitsSection } from "./sections/BenefitsSection";
import { CallToActionSection } from "./sections/CallToActionSection";
import { CategoriesSection } from "./sections/CategoriesSection";
import { CustomerReviewsSection } from "./sections/CustomerReviewsSection";
import { FeaturedProductsSection } from "./sections/FeaturedProductsSection/FeaturedProductsSection";
import { FooterSection } from "./sections/FooterSection";
import { HeroSection } from "./sections/HeroSection";
import { NavigationSection } from "./sections/NavigationSection";

export const Frame = (): JSX.Element => {
  // Brand logos data for the trusted by section
  const brandLogos = [
    { id: 1, url: "..//brand-logo-10.png" },
    { id: 2, url: "..//brand-logo-11.png" },
    { id: 3, url: "..//brand-logo-6.png" },
    { id: 4, url: "..//brand-logo-9.png" },
    { id: 5, url: "..//brand-logo-8.png" },
    { id: 6, url: "..//brand-logo-7.png" },
  ];

  return (
    <div className="flex flex-col w-full">
      <NavigationSection />
      <HeroSection />
      <CategoriesSection />
      <FeaturedProductsSection />
      <BenefitsSection />
      <CallToActionSection />
      <CustomerReviewsSection />
      <FooterSection />
    </div>
  );
};
