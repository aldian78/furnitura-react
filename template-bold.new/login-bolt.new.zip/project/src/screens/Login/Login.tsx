import React from "react";
import { BenefitsSection } from "./sections/BenefitsSection";
import { CartSection } from "./sections/CartSection";
import { FooterSection } from "./sections/FooterSection";
import { NavigationSection } from "./sections/NavigationSection";
import { RegistrationTitleSection } from "./sections/RegistrationTitleSection";

export const Login = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full min-h-screen bg-bg-1">
      <NavigationSection />
      <RegistrationTitleSection />
      <CartSection />
      <BenefitsSection />
      <FooterSection />
    </div>
  );
};
