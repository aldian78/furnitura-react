import {
  CreditCardIcon,
  GlobeIcon,
  MailIcon,
  PackageIcon,
  PhoneIcon,
} from "lucide-react";
import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const BenefitsSection = (): JSX.Element => {
  // Define benefits data for mapping
  const benefitsData = [
    {
      icon: <GlobeIcon className="w-[60px] h-[60px]" />,
      title: "GLOBAL DELIVERY",
      description:
        "Experience Hassle-Free Shipping and Seamless Global Connectivity with Our Trustworthy and Efficient Delivery Service, Bringing the World to Your Fingertips!",
    },
    {
      icon: <PackageIcon className="w-[60px] h-[60px]" />,
      title: "FREE SHIPPING",
      description:
        "Shop to Your Heart's Content Without Worrying About Shipping Costs: Our Free Shipping Service Delivers Your Purchases with a Smile, Straight to Your Doorstep!",
    },
    {
      icon: <PhoneIcon className="w-[60px] h-[60px]" />,
      title: "24/7 SUPPORTING",
      description:
        "Shop with Confidence Anytime, Anywhere: Our Free Shipping Service Comes with 24/7 Support to Ensure Your Packages Arrive Safely and On Time!",
    },
    {
      icon: <MailIcon className="w-[60px] h-[60px]" />,
      title: "DAILY EMAIL",
      description:
        "Stay Up-to-Date with Your Deliveries: Enjoy the Convenience of Daily Email Updates with Our Free Shipping Service, Making Your Online Shopping Experience Even More Enjoyable!",
    },
    {
      icon: <CreditCardIcon className="w-[60px] h-[60px]" />,
      title: "EASY PAYMENT",
      description:
        "Shop and Pay with Ease: Our Free Shipping Service Not Only Delivers Your Packages for Free, but Also Offers Easy Payment Options, Making Your Shopping Experience a Breeze!",
    },
    {
      icon: (
        <div className="relative w-[60px] h-[60px]">
          <img
            className="absolute w-[49px] h-[60px] top-0 left-[5px]"
            alt="Group"
            src="/group-4.png"
          />
        </div>
      ),
      title: "MONTHLY VOUCHER",
      description:
        "More Than Just Free Shipping: Our Service Rewards Your Loyalty with Monthly Vouchers, Giving You More Reasons to Shop and Save on Your Favorite Products!",
    },
  ];

  return (
    <section className="flex flex-col items-center gap-[72px] py-20 px-6 md:px-12 lg:px-24 xl:px-[264px] w-full">
      <h2 className="font-h1-32-extra-bold text-black-1 text-[32px] leading-[40px] text-center tracking-[0px] font-extrabold">
        WHY CHOOSE US?
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 w-full max-w-[1400px]">
        {benefitsData.map((benefit, index) => (
          <Card key={index} className="border-none shadow-none bg-transparent">
            <CardContent className="flex flex-col items-center gap-6 p-0">
              {benefit.icon}

              <h3 className="font-h3-16-bold text-black-1 text-[16px] leading-[20px] text-center tracking-[0px] font-bold w-full">
                {benefit.title}
              </h3>

              <p className="font-h3-16-medium text-black-3 text-[16px] leading-[20px] text-center tracking-[0px] font-medium">
                {benefit.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
