import {
  FacebookIcon,
  InstagramIcon,
  TwitterIcon,
  YoutubeIcon,
} from "lucide-react";
import React from "react";
import { Separator } from "../../../../components/ui/separator";

// Footer column data for mapping
const footerColumns = [
  {
    title: "CUSTOMER SERVICE",
    links: [
      "Help & FAQs",
      "Return & Refund",
      "Shipping Policy",
      "Customs and Taxes",
      "Customers's Reviews",
    ],
  },
  {
    title: "COMPANY",
    links: [
      "About Japan with love",
      "Contact Us",
      "Special Deals & Offers",
      "Terms of Service",
      "Privacy Policy",
    ],
  },
  {
    title: "HELP CENTER",
    links: [
      "Order Information",
      "Shipping Options",
      "International Shipping",
      "Payment Options",
    ],
  },
  {
    title: "RETURN & WARRANTLY",
    links: [
      "Returns & Exchange Policy",
      "Returns Center",
      "Warranty Policy",
      "Warranty Registration",
      "Warranty Repair Center",
    ],
  },
];

export const FooterSection = (): JSX.Element => {
  return (
    <footer className="flex flex-col items-center gap-[72px] pt-28 pb-[72px] px-6 md:px-16 lg:px-[264px] relative bg-bg-1 w-full">
      <div className="gap-8 md:gap-[120px] w-full flex flex-wrap md:flex-nowrap items-start">
        {footerColumns.map((column, index) => (
          <div key={index} className="flex flex-col gap-7 flex-1 min-w-[200px]">
            <h2 className="font-h2-20-extra-bold text-black-1 text-[length:var(--h2-20-extra-bold-font-size)] leading-[var(--h2-20-extra-bold-line-height)] tracking-[var(--h2-20-extra-bold-letter-spacing)] [font-style:var(--h2-20-extra-bold-font-style)]">
              {column.title}
            </h2>
            {column.links.map((link, linkIndex) => (
              <a
                key={linkIndex}
                href="#"
                className="font-h3-16-medium text-black-3 text-[length:var(--h3-16-medium-font-size)] leading-[var(--h3-16-medium-line-height)] tracking-[var(--h3-16-medium-letter-spacing)] [font-style:var(--h3-16-medium-font-style)] hover:underline"
              >
                {link}
              </a>
            ))}
          </div>
        ))}
      </div>

      <Separator className="w-full" />

      <div className="flex flex-col md:flex-row items-center md:items-start justify-between w-full gap-6 md:gap-[72px]">
        <div className="font-h3-16-medium text-black-3 text-[length:var(--h3-16-medium-font-size)] leading-[var(--h3-16-medium-line-height)] tracking-[var(--h3-16-medium-letter-spacing)] [font-style:var(--h3-16-medium-font-style)]">
          Furnitur © Copyright 2020, Inc. All rights reserved
        </div>

        <div className="flex items-center gap-8">
          <a href="#" className="text-black-3 hover:text-black-1">
            <FacebookIcon size={20} />
          </a>
          <a href="#" className="text-black-3 hover:text-black-1">
            <TwitterIcon size={20} />
          </a>
          <a href="#" className="text-black-3 hover:text-black-1">
            <InstagramIcon size={20} />
          </a>
          <a href="#" className="text-black-3 hover:text-black-1">
            <YoutubeIcon size={20} />
          </a>
        </div>
      </div>
    </footer>
  );
};
