export { RegistrationTitleSection } from "./RegistrationTitleSection";
