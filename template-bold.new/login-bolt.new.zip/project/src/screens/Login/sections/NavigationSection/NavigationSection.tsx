import {
  ChevronDownIcon,
  HeartIcon,
  SearchIcon,
  ShoppingBagIcon,
} from "lucide-react";
import React from "react";
import { Input } from "../../../../components/ui/input";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "../../../../components/ui/navigation-menu";

// Navigation menu items data
const mainNavItems = [
  { label: "HOME", hasDropdown: false },
  { label: "SHOP", hasDropdown: true },
  { label: "BLOG", hasDropdown: false },
  { label: "ABOUT US", hasDropdown: false },
];

// Right side menu items with icons
const rightNavItems = [
  { label: "LOVE", icon: HeartIcon },
  { label: "CART", icon: ShoppingBagIcon },
];

export const NavigationSection = (): JSX.Element => {
  return (
    <header className="flex w-full items-center gap-20 px-16 py-[60px] relative bg-black-8">
      <img className="relative h-[42px]" alt="Logo" src="/logo.svg" />

      <div className="flex items-center gap-3 px-0 py-3 relative border-b border-neutral-300">
        <SearchIcon className="w-5 h-5 text-black-3" />
        <Input
          className="border-none p-0 h-auto font-h3-16-medium text-black-3 placeholder:text-black-3 focus-visible:ring-0"
          placeholder="SearchIcon something"
        />
      </div>

      <NavigationMenu className="flex-1">
        <NavigationMenuList className="flex items-center gap-11">
          {mainNavItems.map((item, index) => (
            <NavigationMenuItem key={index} className="flex items-start">
              {item.hasDropdown ? (
                <>
                  <NavigationMenuTrigger className="p-0 bg-transparent hover:bg-transparent focus:bg-transparent">
                    <span className="font-h3-16-bold text-black-1">
                      {item.label}
                    </span>
                    <ChevronDownIcon className="w-5 h-5 ml-0.5" />
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    {/* Dropdown content would go here */}
                  </NavigationMenuContent>
                </>
              ) : (
                <span className="font-h3-16-bold text-black-1 cursor-pointer">
                  {item.label}
                </span>
              )}
            </NavigationMenuItem>
          ))}
        </NavigationMenuList>
      </NavigationMenu>

      <div className="flex items-center justify-end gap-11">
        {rightNavItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className="inline-flex items-center gap-1 cursor-pointer"
            >
              <Icon className="w-5 h-5 text-black-1" />
              <span className="font-h3-16-bold text-black-1">{item.label}</span>
            </div>
          );
        })}
      </div>
    </header>
  );
};
